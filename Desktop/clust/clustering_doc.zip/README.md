# commit conventiondocs
#### `feat, fix, perf, style, refactor, test` 사용

## Commit Type
commit convention 은 Conventional Commits/Angular convention 을 따름

#### Must be one of the following:
`build`: 빌드 시스템이나 외부 종속성에 영향을 주는 변경 사항 (예: gulp, broccoli, npm)  
`ci`: CI 구성 파일 및 스크립트에 대한 변경 사항 (예: Travis, Circle, BrowserStack, SauceLabs)  
`docs`: 문서 변경 사항  
`feat`: 새로운 기능 추가  
`fix`: 버그 수정  
`perf`: 성능을 개선하는 코드 변경  
`refactor`: 버그 수정이나 기능 추가를 하지 않고 코드를 재구성하는 변경 사항  
`style`: 코드 의미에 영향을 주지 않는 변경 사항 (공백, 포맷팅, 세미콜론 누락 등)  
`test`: 누락된 테스트 추가 또는 기존 테스트 수정  

## branch depth
#### branch depth: main, dev, feature
`main`: 최종 버전 관리 레벨  
`dev`: 새로운 기능(프로그램 작동 레벨) 구현 레벨  
`feature`: 기능 별 코드(함수나 클래스) 구현 레벨
<br>
### Follow This Steps
1) 버전 별 dev 브랜치 따기
2) 코드레벨 구현할때마다 issue 등록 
3) feature 브랜치를 lcw-, lhj-, lbh-* 등과 같이 따고, 등록한 issue랑 연결
4) 커밋시 '#이슈번호'를 함께 입력하면 해당 커밋과 이슈가 연결됨
5) PR은 반드시 dev 브랜치로 날리기
### Example
issue: caption 추가 버튼 개발-lcw-1  
branch: lcw-1, 이슈와 연결
